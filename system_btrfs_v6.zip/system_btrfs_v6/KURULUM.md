# NixOS 26.05 Taze Kurulum Adımları

## 1. Disk hazırlığı (hardware-configuration.nix'teki yorum bloğuna bak)
```bash
sgdisk -Z /dev/nvme0n1
sgdisk -n 1:0:+1G  -t 1:ef00 -c 1:"EFI"  /dev/nvme0n1
sgdisk -n 2:0:+8G  -t 2:8200 -c 2:"SWAP" /dev/nvme0n1
sgdisk -n 3:0:0    -t 3:8309 -c 3:"ROOT" /dev/nvme0n1
```

## 2. LUKS2 şifreleme
```bash
cryptsetup luksFormat --type luks2 \
  --cipher aes-xts-plain64 --key-size 512 \
  --hash sha256 --pbkdf argon2id \
  /dev/nvme0n1p3
cryptsetup open /dev/nvme0n1p3 cryptroot
```

## 3. Btrfs + subvolume'ler
```bash
mkfs.btrfs -L nixos /dev/mapper/cryptroot
mount /dev/mapper/cryptroot /mnt
for sv in @ @home @nix @log @snapshots; do
  btrfs subvolume create /mnt/$sv
done
umount /mnt
```

## 4. UUID'leri al ve hardware-configuration.nix'e gir
```bash
cryptsetup luksUUID /dev/nvme0n1p3    # → LUKS-UUID-BURAYA
blkid /dev/mapper/cryptroot           # → BTRFS-UUID-BURAYA
blkid /dev/nvme0n1p1                  # → EFI-UUID-BURAYA
blkid /dev/nvme0n1p2                  # → SWAP-UUID-BURAYA
```

## 5. Şifre hash'i oluştur (güvenlik)
```bash
# Kurulum ortamında hash üret, /etc/nixos'a koy:
nix-shell -p mkpasswd --run "mkpasswd -m sha-512" > /mnt/etc/nixos/passwd-umpug
chmod 600 /mnt/etc/nixos/passwd-umpug
```
> configuration.nix'teki `hashedPasswordFile = "/etc/nixos/passwd-umpug"` bu dosyayı okur.

## 6. Config'i git ile al
```bash
mkdir -p /mnt/etc/nixos
cd /mnt/etc/nixos

# Seçenek A — bu repoyu clone et:
git clone https://github.com/SENIN-REPO/nixos-config .

# Seçenek B — dosyaları zip'ten kopyala:
# cp -r /path/to/system/nixos/* /mnt/etc/nixos/

# UUID'leri hardware-configuration.nix'e gir (adım 4)
nano hardware-configuration.nix

# flake.lock oluştur (internet gerekli):
nix flake update
```

## 7. Kur
```bash
nixos-install --flake /etc/nixos#nixos
```

## 8. İlk boot sonrası
```bash
# Hyprland/waybar/hyprlock config'lerini yerleştir:
cp -r system/hypr    ~/.config/
cp -r system/waybar  ~/.config/
cp -r system/gtk-3.0 ~/.config/
cp -r system/gtk-4.0 ~/.config/
```

## Not: cachyos-kernel overlay sorunu
Eğer `nixos-26.05` branch ile overlay uyumsuzluk çıkarsa flake.nix'te:
```nix
nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
```
olarak değiştir, `nix flake update` çalıştır.
